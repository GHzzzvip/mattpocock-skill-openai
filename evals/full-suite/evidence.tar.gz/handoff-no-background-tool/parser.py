def parse_items(text):
    return text.split(',')
