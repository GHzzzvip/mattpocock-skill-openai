def create_product(id, name, price):
    if price < 0:
        raise ValueError("price must be nonnegative")
    return {"id": id, "name": name, "price": price}

def display_name(product):
    return product["name"].upper()

def total_price(products):
    return sum(product["price"] for product in products)
