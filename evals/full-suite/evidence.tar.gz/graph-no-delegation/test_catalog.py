import unittest
from catalog import *

class Tests(unittest.TestCase):
    def test_create(self):
        self.assertEqual(create_product(1, "Book", 3), {"id": 1, "name": "Book", "price": 3})
        self.assertEqual(create_product(2, "Free", 0)["price"], 0)
        with self.assertRaises(ValueError):
            create_product(3, "Bad", -1)
    def test_display(self):
        self.assertEqual(display_name(create_product(1, "Book", 3)), "BOOK")
    def test_total(self):
        self.assertEqual(total_price([create_product(1, "A", 3), create_product(2, "B", 5)]), 8)
        self.assertEqual(total_price([]), 0)
