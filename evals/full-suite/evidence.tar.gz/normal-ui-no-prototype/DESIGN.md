---
version: alpha
name: Settings
description: Native settings form
omitted:
  - section: colors
    reason: Platform colors retained; scrollbar values owned by index.html
  - section: typography
    reason: Existing browser defaults retained
  - section: rounded
    reason: Native controls own geometry
  - section: spacing
    reason: Minimal layout owned by index.html
  - section: components
    reason: Single native form, no shared component library
---
# Settings design

## Overview
Product form for editing a display name and email notifications. approved.md is the complete business specification. English-only existing page; no market-specific assumptions. Preserve native HTML appearance, with no framework or visual variants. Browser settings panels are the reference; promotional graphics and card dashboards are inappropriate.

## Layout
Single column within the existing #settings, natural document scrolling, maximum width 32rem, form gap 1rem. Save feedback has reserved height.

## Components
The existing page is the canonical Form owner; settings.js owns local read/save and the status live region. No sibling workflow exists. Text and checkbox inputs retain native keyboard behavior. Saves stay on this page. Failed storage operations preserve input. No required-field constraints were specified. Scrollbars use index.html root tokens (thumb #666, track #fff, hover #444, active #222) with system forced colors. Runtime CSS is canonical; no theme adapter or generated token layer exists. No network or async loading state exists.

## Do's and Don'ts
Use labels, native focus behavior, visible keyboard focus, and concise status messages. Do not add a framework, visual variants, extra settings, or remote saves.
