(() => {
  const form = document.getElementById('settings-form');
  const displayName = document.getElementById('display-name');
  const emailNotifications = document.getElementById('email-notifications');
  const status = document.getElementById('save-status');
  const snapshot = () => JSON.stringify({
    displayName: displayName.value,
    emailNotifications: emailNotifications.checked,
  });

  try {
    const stored = localStorage.getItem('settings');
    if (stored !== null) {
      const settings = JSON.parse(stored);
      if (!settings || typeof settings.displayName !== 'string' ||
          typeof settings.emailNotifications !== 'boolean') {
        throw new Error('Invalid settings');
      }
      displayName.value = settings.displayName;
      emailNotifications.checked = settings.emailNotifications;
    }
  } catch {
    status.textContent = 'Could not load settings. Enter your preferences and save to try again.';
  }

  let saved = snapshot();
  form.addEventListener('input', () => { status.textContent = ''; });
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    try {
      const value = snapshot();
      localStorage.setItem('settings', value);
      saved = value;
      status.textContent = 'Saved';
    } catch {
      status.textContent = 'Could not save settings. Your changes are still here. Try Save again.';
    }
  });
  window.addEventListener('beforeunload', (event) => {
    if (snapshot() !== saved) {
      event.preventDefault();
      event.returnValue = '';
    }
  });
})();
