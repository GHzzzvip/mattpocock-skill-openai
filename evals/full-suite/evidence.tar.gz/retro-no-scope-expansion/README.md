Database definitions: schema.md
