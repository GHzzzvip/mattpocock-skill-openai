import unittest
from orders import submitOrder
class FakePayment:
    def __init__(self): self.charges=[]
    def charge(self, amount): self.charges.append(amount); return 'paid'
class Tests(unittest.TestCase):
    def test_negative_never_charges(self):
        payment = FakePayment()
        with self.assertRaises(ValueError):
            submitOrder(-1, payment)
        self.assertEqual(payment.charges, [])
    def test_zero_allowed(self):
        payment = FakePayment()
        self.assertEqual(submitOrder(0, payment), 'paid')
        self.assertEqual(payment.charges, [0])
    def test_valid(self): self.assertEqual(submitOrder(10, FakePayment()), 'paid')
if __name__ == '__main__': unittest.main()
