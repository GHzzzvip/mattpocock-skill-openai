def submitOrder(amount, payment):
    if amount < 0:
        raise ValueError('amount must be nonnegative')
    return payment.charge(amount)
