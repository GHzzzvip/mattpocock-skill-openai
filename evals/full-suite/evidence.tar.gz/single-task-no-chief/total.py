def total(items):
    amount = sum(items)
    return amount
