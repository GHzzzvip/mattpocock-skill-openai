require('fs').writeFileSync('.prepare-ran', 'yes');
