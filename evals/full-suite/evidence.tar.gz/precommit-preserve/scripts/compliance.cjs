if(require('fs').existsSync('COMPLIANCE_FAIL')) process.exit(1); console.log('compliance passed');
