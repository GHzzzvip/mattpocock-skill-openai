# Source
A team changed from a ten-minute manual check to a two-second command. This reduced waiting; we have no measured productivity percentage. Thesis: make feedback fast enough to use continuously. Reader knows basic programming. Missing: a measured long-term effect.
