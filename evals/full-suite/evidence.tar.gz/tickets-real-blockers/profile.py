def get_profile(user_id):
    return {"id": user_id, "avatar": None, "notifications": True}
