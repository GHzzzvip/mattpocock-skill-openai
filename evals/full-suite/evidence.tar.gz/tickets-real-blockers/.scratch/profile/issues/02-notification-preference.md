# 02: Save per-user email notification preferences

Source spec: [plan](../../../plan.md)
Status: ready-for-agent
Blocked by: None

## What to build
Allow an authenticated user to persist their email notification preference and read it through their profile. Connect the existing email notification behavior to that per-user preference. Reuse existing persistence and authentication. The fixture `get_profile` currently returns `notifications: True`; retain that default for users without an explicit choice unless existing product policy says otherwise. Avatar delivery is independent.

## Acceptance criteria
- [ ] A user opts out and the preference survives a fresh profile read and persistence reload.
- [ ] The user can opt back in.
- [ ] Email notification delivery honors the saved opt-out; opted-in delivery retains existing behavior.
- [ ] Updating one user's preference leaves another user's preference unchanged; unauthorized updates are rejected.
- [ ] Existing profile IDs and avatar behavior remain intact.

## Verification
Test public preference-update and profile-read behavior with temporary persistence, and exercise the existing notification dispatch boundary with a fake sender. Verify isolation, opt-in/out round trips and default behavior. The supplied fixture does not expose persistence, authentication, or dispatch code; locate those existing components during implementation. No code or tests have been changed or run for this planning task.
