# 01: Upload and retain a profile avatar

Source spec: [plan](../../../plan.md)
Status: ready-for-agent
Blocked by: None

## What to build
Deliver authenticated avatar upload through the existing storage adapter, persist the user's avatar reference, and return it through the profile interface. Reuse existing authentication and persistence; do not add shared infrastructure or redesign. `profile.py` currently returns a placeholder avatar. Locate the actual adapter during implementation. Accepted image types and maximum size are unspecified: reuse existing policy if present, otherwise obtain the policy before finalizing validation.

## Acceptance criteria
- [ ] An authenticated user uploads an allowed image within the established size limit and retrieves their persisted avatar through the profile interface.
- [ ] Disallowed types and oversized images are rejected without replacing the existing avatar.
- [ ] One user's upload cannot change another user's avatar; unauthenticated upload is rejected.
- [ ] A failed storage operation does not expose a successful persisted avatar change.
- [ ] Notification preferences continue to work independently.

## Verification
Exercise the authenticated upload and profile interfaces with temporary persistence and a controlled storage adapter. Cover successful retrieval, invalid type, size boundary and exceeded size, unauthorized access, and storage failure. Record actual policy values and observed results when implemented. No implementation or tests have been executed for this planning task.
