# Draft questionnaire: Migration downtime and rollback

Recipient: Internal PostgreSQL database owner.

Purpose: Choose an acceptable migration downtime window and a workable rollback plan. Your answers will guide scheduling, readiness checks, and approval. The migration details and operational limits have not yet been supplied; please identify where more information is needed. No deadline has been set. Partial answers, estimates, and explicit unknowns are welcome; note supporting evidence where available. This is an unsent draft.

## Downtime and approval

1. What is the maximum acceptable duration of database unavailability for this migration?

   Answer: 

2. What maintenance windows would be acceptable? Please include timezone.

   Answer: 

3. Which user-visible operations must remain available during migration?

   Answer: 

4. Who has authority to approve the downtime window?

   Answer: 

5. What evidence does that approver need before making the decision?

   Answer: 

## Rollback

6. What recovery-time limit should the rollback plan meet?

   Answer: 

7. What data-loss tolerance should the rollback plan meet?

   Answer: 

8. Which conditions should trigger rollback?

   Answer: 

9. Who can authorize rollback during the migration?

   Answer: 

10. Which rollback method is viable for the planned migration? Please mark any uncertainty.

   Answer: 

11. At what point, if any, would rollback cease to be feasible?

   Answer: 

12. How should writes accepted after migration begins be handled during rollback?

   Answer: 

## Load and replication

13. When is database load lowest, based on available workload evidence?

   Answer: 

14. Which long-running transactions or scheduled workloads could overlap a candidate window?

   Answer: 

15. What replication topology and failover arrangement must this migration accommodate?

   Answer: 

16. What replication-lag limit must hold before proceeding?

   Answer: 

17. What replication or failover risks could extend downtime or complicate rollback?

   Answer: 

## Compatibility

18. What PostgreSQL versions and extensions are involved?

   Answer: 

19. Which application or client compatibility constraints limit migration sequencing?

   Answer: 

20. What schema or data changes could prevent the previous application version from running after rollback?

   Answer: 

## Rehearsal and readiness

21. What representative environment or data can we use for rehearsal?

   Answer: 

22. What migration and rollback timing evidence do we already have?

   Answer: 

23. Which rehearsal results would establish readiness for production?

   Answer: 

24. What checks should confirm database and application health before service resumes?

   Answer: 

25. Who will own the migration and rollback execution?

   Answer: 

## Other considerations

What important constraints, risks, or people have we missed?

Answer: 
