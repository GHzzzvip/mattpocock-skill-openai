# Draft: Archive and restore notes

Source: [agreed plan](../../plan.md) (workspace `plan.md`).

## Problem
Users need to remove notes from the active list while retaining the ability to find and restore them. The supplied plan does not describe existing archive behavior.

## Desired behavior and agreed decisions
A note transitions from active to archived when archived and from archived to active when restored. Archived notes are hidden from the active list. Search with `include_archived=true` includes archived notes. Note IDs remain stable through both transitions. Storage remains local SQLite; test the behavior through NoteService. Archival must retain the note rather than permanently delete it.

## Acceptance checks
- Archive an active note: it disappears from the active list and remains findable with `include_archived=true` using its original ID.
- Restore that note: it returns to the active list with its original ID and content.
- Archive one of two notes: the other remains active and unchanged.
- Persist and reopen SQLite storage: the archived state and retained content survive.
- No permanent-deletion behavior is introduced.

## Proposed implementation details, not agreed requirements
Represent archival as persistent note state in SQLite, defaulting existing notes to active. Reuse the current NoteService error conventions for unknown IDs. Suggested repeat behavior is idempotent archive/restore; confirm against existing service conventions during implementation. The exact schema and service signatures require code inspection because only the plan is supplied.

## Verification
Exercise archive, restore, active listing, and archived-inclusive search via NoteService backed by a temporary SQLite database. Include state round trips, unaffected notes, and reopening storage. These checks cover the public service contract and persistence, but do not establish UI rendering, real quota integration, or concurrent-client behavior. There is no supplied executable test suite or code, so no tests have been run.

## Exclusions
Permanent deletion, new storage systems, unrelated note editing, and quota-policy changes are outside this draft's agreed scope.

## Open questions and risks
Do archived notes count toward quota? Undecided. This affects quota calculation and potentially restore behavior when a quota is reached; quota-dependent acceptance tests remain pending that decision. Drafting and core archive-state work can proceed. Also confirm default search behavior, repeat-operation semantics, and existing unknown-ID behavior from the service when available; this draft does not claim those were agreed.
