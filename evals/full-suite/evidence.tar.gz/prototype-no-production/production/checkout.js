export function checkout(cart) { return {state:'confirmed', cart}; }
