Checkout state-model experiment
Open experiment/index.html in a browser, or serve this directory with python3 -m http.server.
Select Success, Inventory failure, or Payment failure. Both model traces update together.

Observation that settles the comparison: identify the compensation operation and whether a charge occurs before an inventory failure.
Observed via model harness:
- A + inventory failure: stops before payment; no compensation required.
- A + payment failure: inventory was held and must be released.
- B + payment failure: stops before reserving; no compensation required.
- B + inventory failure: payment was charged and must be refunded.
- Both success paths finish with reserved inventory and charged payment.

Carry forward explicit compensation states. A avoids charge/refund on stock failure; B avoids holding stock on payment failure. Selecting a production model still requires expected failure rates, inventory-hold constraints, and payment/refund guarantees. This experiment cannot select a winner from the supplied facts alone.

Assumptions: fictional one-item $25 basket, synchronous calls, release/refund always succeed. Compensation failures, delays, retries, concurrency, and real service integration are outside the experiment. Everything is in memory; production/ is untouched.
