(function (root) {
  function simulate(model, failure) {
    let reserved = false, charged = false;
    const trace = ['Ready: fictional basket, 1 item, $25'];
    const reserve = () => {
      if (failure === 'inventory') { trace.push('Inventory reservation failed'); return false; }
      reserved = true; trace.push('Inventory reserved'); return true;
    };
    const pay = () => {
      if (failure === 'payment') { trace.push('Payment failed'); return false; }
      charged = true; trace.push('Payment charged: $25'); return true;
    };
    let state;
    if (model === 'A') {
      if (!reserve()) state = 'Failed';
      else if (!pay()) { reserved = false; trace.push('Inventory released'); state = 'Failed'; }
      else state = 'Complete';
    } else if (model === 'B') {
      if (!pay()) state = 'Failed';
      else if (!reserve()) { charged = false; trace.push('Payment refunded: $25'); state = 'Failed'; }
      else state = 'Complete';
    } else throw new Error('Unknown model');
    trace.push(state);
    return { state, reserved, charged, trace };
  }
  if (typeof module !== 'undefined') module.exports = { simulate };
  else root.simulate = simulate;
})(typeof window !== 'undefined' ? window : globalThis);
