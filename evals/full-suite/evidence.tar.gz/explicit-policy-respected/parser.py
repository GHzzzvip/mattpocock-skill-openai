def parse_items(text):
    return [] if text == '' else text.split(',')
