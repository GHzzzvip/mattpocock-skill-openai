import unittest
from parser import parse_items
class Tests(unittest.TestCase):
    def test_empty(self): self.assertEqual(parse_items(''), [])
    def test_two(self): self.assertEqual(parse_items('a,b'), ['a','b'])
if __name__ == '__main__': unittest.main()
