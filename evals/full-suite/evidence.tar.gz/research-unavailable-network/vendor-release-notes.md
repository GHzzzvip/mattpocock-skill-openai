# AcmeWidget official release notes (fixture primary source)
Published 2025-02-01. AcmeWidget 2 supports Runtime 18 and 20. AcmeWidget 3 supports Runtime 20 and 22. This snapshot contains no later release information.
