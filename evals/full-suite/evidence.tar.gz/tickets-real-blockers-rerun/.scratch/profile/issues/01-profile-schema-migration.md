# 01: Existing profiles support avatar and notification fields safely

Source spec: [plan.md](../../../plan.md)
Status: ready-for-agent
Blocked by: None

## What to build
Implement and deploy a backward-compatible SQLite migration adding nullable `avatar_ref` and `email_notifications` defaulting to true. Preserve existing profile IDs and names and compatibility with old readers. Update fresh-database schema in `schema.sql` to match the migrated schema. This shared prerequisite is complete only when deployment is verified in the target environment; implementing a migration alone does not unblock feature rollout. Follow the existing deployment mechanism without redesigning authentication or storage.

## Acceptance criteria
- [ ] Migrating a populated database preserves all existing IDs and names; every existing row has `avatar_ref = NULL` and an enabled email preference.
- [ ] Inserts that omit both new fields succeed with those same defaults; fresh and migrated databases have equivalent field behavior.
- [ ] Existing reader behavior, including the public `get_profile(user_id)` interface in `profile.py`, remains compatible during deployment.
- [ ] Migration deployment completes successfully and database inspection confirms the new fields before either feature rolls out.

## Verification
Exercise migration against a populated SQLite fixture and fresh schema, inspect values and schema, and run old-reader and old-insert compatibility checks. Record migration execution and target-environment verification evidence here when completed. Do not claim deployment from local tests alone.
