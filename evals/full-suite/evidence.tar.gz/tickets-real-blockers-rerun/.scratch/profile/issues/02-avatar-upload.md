# 02: A user can upload and retrieve a profile avatar

Source spec: [plan.md](../../../plan.md)
Status: blocked
Blocked by: [01](01-profile-schema-migration.md)

## What to build
Deliver the avatar upload behavior through the existing authentication and storage adapters, persisting the returned storage reference in the authenticated user's `avatar_ref` and exposing it through profile retrieval in `profile.py`. Accept PNG and JPEG images up to and including 5 MiB (5,242,880 bytes). Validate actual image format rather than trusting an extension or declared media type. Keep profiles with no avatar readable. Do not redesign adapters. Task 03 is independent; neither implementation nor rollout requires notification preferences to be delivered first.

## Acceptance criteria
- [ ] An authenticated user can upload a valid PNG or JPEG within the size limit; storage is called through its existing adapter and subsequent profile reads expose the saved avatar reference.
- [ ] A valid image at exactly 5 MiB is accepted; an image above the limit, an unsupported format, or invalid image data is rejected without changing the saved reference.
- [ ] A failed storage operation leaves the previous reference intact and reports an observable error.
- [ ] Authentication prevents an unauthenticated request or an attempt to target another user's profile from updating that profile.
- [ ] A profile whose `avatar_ref` is NULL remains readable, and uploading an avatar preserves its name and email preference.

## Verification
Use the public upload and profile retrieval interfaces with existing adapter test doubles or configured local adapters. Demonstrate persistence across a new read, both allowed formats, boundary size cases, invalid data, storage failure, and user isolation. Roll out only after Task 01's migration deployment is verified; record evidence here at completion.
