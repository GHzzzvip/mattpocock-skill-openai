# 03: A user can persist an email notification preference

Source spec: [plan.md](../../../plan.md)
Status: blocked
Blocked by: [01](01-profile-schema-migration.md)

## What to build
Deliver authenticated per-user reading and updating of `email_notifications`, including persistence and exposure through profile retrieval in `profile.py`. Existing and new profiles default to enabled. Accept explicit boolean updates and reject invalid values. Use existing authentication, preserving the profile's other fields. Task 02 is independent; this feature must work for users without an avatar and requires no avatar upload implementation. The source specifies preference management; do not invent a notification delivery subsystem.

## Acceptance criteria
- [ ] Existing and newly created profiles report enabled notifications by default.
- [ ] A user can disable and re-enable the preference; subsequent independent reads return the persisted boolean value, including explicit false.
- [ ] Invalid values produce an observable validation error and preserve the stored preference.
- [ ] Unauthenticated requests and attempts to update another user's preference are denied without changing it.
- [ ] Updating the preference preserves the profile name and avatar reference, including NULL, and works before Task 02 is delivered.

## Verification
Exercise preference update and profile retrieval through their public interfaces against a migrated SQLite fixture. Demonstrate default, false and true persistence, invalid input, user isolation, and preservation of unrelated fields. Roll out only after Task 01's migration deployment is verified; record evidence here at completion.
