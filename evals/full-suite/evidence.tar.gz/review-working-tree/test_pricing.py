import unittest
from pricing import total
class Tests(unittest.TestCase):
    def test_three(self): self.assertEqual(total(10,3),30)
