Use total(price, count) for the total. Counts are nonnegative.
