def deactivate_user(user):
    return {**user, "active": False}
