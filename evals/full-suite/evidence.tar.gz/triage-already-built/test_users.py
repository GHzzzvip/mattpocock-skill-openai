import unittest
from users import deactivate_user
class Tests(unittest.TestCase):
    def test_disable(self): self.assertFalse(deactivate_user({"active":True})["active"])
