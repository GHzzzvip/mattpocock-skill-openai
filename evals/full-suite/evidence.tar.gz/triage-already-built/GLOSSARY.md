# Terms
Suspension: deactivating a user, preserving their data.
